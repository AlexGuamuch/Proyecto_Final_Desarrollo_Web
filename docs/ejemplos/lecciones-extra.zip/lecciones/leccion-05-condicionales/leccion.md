# Condicionales

Un programa puede tomar decisiones con `if` y `else`: ejecuta un bloque si una condición es verdadera y otro si es falsa.

## Copia este código

```java
public class Main {
    public static void main(String[] args) {
        int nota = 75;

        if (nota >= 61) {
            System.out.println("Aprobado con " + nota);
        } else {
            System.out.println("Reprobado con " + nota);
        }
    }
}
```

## Fíjate en

- La condición va entre paréntesis: `(nota >= 61)`.
- Cada bloque tiene sus propias llaves `{ }`.
- Después de `if (...)` **no** va punto y coma.
- Cambia `75` por `40` y vuelve a ejecutar: debe salir el otro mensaje.

## Objetivo

Compila y ejecuta el programa sin errores. La consola debe mostrar:

```
Aprobado con 75
```
